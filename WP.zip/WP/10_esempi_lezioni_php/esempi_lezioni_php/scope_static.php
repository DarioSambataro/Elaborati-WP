<?php
    
    function f()
    {
        static $x = 0;
        $x++;
        echo '$x dentro la funzione: '.$x.'<br>';
    }

    f();
    f();
    f();

?>





