<?php

    $nome = "Anna";
    echo "Ciao $nome!<br>";
    echo 'Ciao $nome!<br>';

?>