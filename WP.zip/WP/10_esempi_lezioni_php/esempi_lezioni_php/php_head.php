<html>
    <head>
        <title>
            <?php
                echo "Pagina di oggi ".date("d-m-Y");
            ?>
        </title>
    </head>
    <body>
    <?php
        echo "<h1>Hello PHP</h1>";
        echo "<p>Il PHP è un linguaggio di scripting per la programmazione server-side</p>";
    ?>
    </body>
</html>