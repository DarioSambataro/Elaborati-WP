<?php
    
    function f()
    {
        echo '$x dentro la funzione: '.$x.'<br>';
    }

    $x = 10;
    echo '$x fuori dalla funzione: '.$x.'<br>';
    f();

?>





