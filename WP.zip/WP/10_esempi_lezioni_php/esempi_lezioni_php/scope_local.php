<?php

    function f()
    {
        $x = 10;
        echo '$x dentro la funzione: '.$x.'<br>';
    }
    
    f();
    echo '$x fuori dalla funzione: '.$x.'<br>';

?>


