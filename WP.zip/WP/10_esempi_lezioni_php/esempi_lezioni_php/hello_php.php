<html>
    <head>
    </head>
    <body>
    <?php
        echo "<h1>Hello PHP</h1>";
        echo "<p>Il PHP è un linguaggio di scripting per la programmazione server-side</p>";
    ?>
    </body>
</html>


