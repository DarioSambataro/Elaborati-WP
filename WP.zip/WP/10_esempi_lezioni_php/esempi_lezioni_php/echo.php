<?php

    echo "Hello world";

?>