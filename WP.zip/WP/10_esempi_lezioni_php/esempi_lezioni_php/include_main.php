<?php

    include('include_f.php');

    f();

?>

