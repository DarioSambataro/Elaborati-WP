<?php

    echo "L'anno scorso era ".(date("Y")-1)."<br>";
    echo 'L\'anno scorso era '.(date('Y')-1)."<br>";

?>