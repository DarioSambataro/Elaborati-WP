function onTextResponse(text)
{
    console.log(text);
}

function onRequestResponse(response)
{
    return response.text();
}

fetch("http://localhost")
    .then(onRequestResponse)
    .then(onTextResponse);