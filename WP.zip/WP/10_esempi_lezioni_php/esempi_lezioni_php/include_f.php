<?php

    function f()
    {
        echo "Ciao<br>";
    }

?>

