<?php
    
    function f()
    {
        global $x;
        echo '$x dentro la funzione: '.$x.'<br>';
    }

    $x = 10;
    echo '$x fuori dalla funzione: '.$x.'<br>';
    f();

?>





