$.ajax({ url: '../phpfiles/getValidationVars.php',
        dataType: 'json',
        success: function(data)
        {
        if(parseInt(data['mode'].localeCompare("edit"))!=0 && parseInt(data['validation'])!=0) //se sono in editing salto la selezione dello strumento
        {
            $('#modal_inizio_taratura').dialog('open');
        }
        else
            if(parseInt(data['validation'])==0)
                $('#modal_error').dialog('open');

        }
    });
	
	
	
    $.ajax({
        url: '@Url.Content("~/AreaModel/GetColumns")',
        data: {
            'id': 10,
        },
        dataType: "json",
        type: 'POST'
    }).done(function (data) {
        debugger;
        var array = $.map(data.list, function (item) {
            return {
                field: "row.Col1.comNm",
                title: " "
            }
        });
        callback(array)
    }).fail(function () {
        alert("error!");
    });
