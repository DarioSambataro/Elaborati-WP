<pre>
<?php

    // Connessione al DB
    $conn = mysqli_connect("localhost", "root", "", "test") or die("Errore: ".mysqli_connect_error());
    // Preparazione query
    $query = "SELECT * FROM users";
    // Esecuzione query
    $res = mysqli_query($conn, $query) or die("Errore: ".mysqli_error($conn));
    // Lettura risultati
    while($row = mysqli_fetch_row($res))
    {
        print_r($row);
    }

?>
</pre>


