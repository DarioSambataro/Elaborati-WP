<html>
    <head>
    </head>
    <body>
        <table>
            <tr><th>Username</th><th>Password</th></tr>
            <?php
                $conn = mysqli_connect("localhost", "root", "", "test") or die("Errore: ".mysqli_connect_error());
                $query = "SELECT * FROM users";
                $res = mysqli_query($conn, $query) or die("Errore: ".mysqli_error($conn));
                while($row = mysqli_fetch_object($res))
                {
                    echo "<tr><td>".$row->username."</td><td>".$row->password."</td></tr>";
                }
            ?>
        </table>
    </body>
</html>

