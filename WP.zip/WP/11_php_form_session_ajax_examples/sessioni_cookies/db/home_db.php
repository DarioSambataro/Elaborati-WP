<?php

    // Avvia la sessione
    session_start();
    // Verifica se l'utente è loggato
    if(!isset($_SESSION['username']))
    {
        // Vai alla login
        header("Location: login_db.php");
        exit;
    }

?>

<html>
    <head>
    </head>
    <body>
        <h1>Benvenuto <?php echo $_SESSION["username"]; ?>!</h1>
        <p><a href='logout_db.php'>Esci dalla sessione</a></p>
    </body>
</html>