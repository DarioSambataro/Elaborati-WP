<?php

    // Avvia la sessione
    session_start();
    // Verifica l'accesso
    if(isset($_SESSION["username"]))
    {
        // Vai alla home
        header("Location: home_db.php");
        exit;
    }
    // Verifica l'esistenza di dati POST
    if(isset($_POST["username"]) && isset($_POST["password"]))
    {
        // Connetti al database
        $conn = mysqli_connect("localhost", "root", "", "test");
        // Cerca utenti con quelle credenziali
        $query = "SELECT * FROM users WHERE username = '".$_POST['username']."' AND password = '".$_POST['password']."'";
        $res = mysqli_query($conn, $query);
        // Verifica la correttezza delle credenziali
        if(mysqli_num_rows($res) > 0)
        {
            // Imposta la variabile di sessione
            $_SESSION["username"] = $_POST["username"];
            // Vai alla pagina home_db.php
            header("Location: home_db.php");
            exit;
        }
        else
        {
            // Flag di errore
            $errore = true;
        }
    }

?>
<html>
    <head>
        <link rel='stylesheet' href='login_db.css'>
        <script src='login_db.js' defer></script>
    </head>
    <body>
        <?php
            // Verifica la presenza di errori
            if(isset($errore))
            {
                echo "<p class='errore'>";
                echo "Credenziali non valide.";
                echo "</p>";
            }
        ?>
        <main>
            <form name='nome_form' method='post'>
                <p>
                    <label>Nome utente <input type='text' name='username'></label>
                </p>
                <p>
                    <label>Password <input type='password' name='password'></label>
                </p>
                <p>
                    <label>&nbsp;<input type='submit'></label>
                </p>
            </form>
        </main>
    </body>
</html>