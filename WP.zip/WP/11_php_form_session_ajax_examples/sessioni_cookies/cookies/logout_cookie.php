<?php

    // Rimuovi cookie (termina sessione)
    setcookie("username", "");
    // Vai alla login
    header("Location: login_cookie.php");
    exit;

?>