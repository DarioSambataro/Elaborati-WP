<?php

    // Verifica se l'utente è loggato
    if(!isset($_COOKIE['username']))
    {
        // Vai alla login
        header("Location: login_cookie.php");
        exit;
    }

?>

<html>
    <head>
    </head>
    <body>
        <h1>Benvenuto <?php echo $_COOKIE["username"]; ?>!</h1>
        <p><a href='logout_cookie.php'>Esci dalla sessione</a></p>
    </body>
</html>