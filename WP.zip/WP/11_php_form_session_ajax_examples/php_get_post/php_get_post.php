<html>
    <head>
    </head>
    <body>
        <h1>Variabile $_GET</h1>
        <pre>
        <?php
            print_r($_GET);
        ?>
        </pre>

        <h1>Variabile $_POST</h1>
        <pre>
        <?php
            print_r($_POST);
        ?>
        </pre>
    </body>
</html>