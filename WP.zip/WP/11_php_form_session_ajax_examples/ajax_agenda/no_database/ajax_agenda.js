function onJSON(json)
{
    const lista = document.querySelector("ul");
    for(evento of json)
    {
        const li = document.createElement("li")
        const orario = document.createElement("em");
        orario.textContent = evento.orario + ": ";
        const descrizione = document.createElement("span");
        descrizione.textContent = evento.descrizione;
        li.appendChild(orario);
        li.appendChild(descrizione);
        lista.appendChild(li);
    }
}

function onResponse(response)
{
    return response.json();
}

// Richiedi lista eventi
fetch("http://localhost/11_examples/ajax_agenda/no_database/ajax_agenda.php").then(onResponse).then(onJSON);