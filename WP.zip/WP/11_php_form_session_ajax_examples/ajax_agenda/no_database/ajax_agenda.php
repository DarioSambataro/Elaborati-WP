<?php

    // Eventi (es. da database)
    $eventi = array(
        array("orario" => "11:00",
              "descrizione" => "Commercialista"
        ),
        array("orario" => "15:00",
              "descrizione" => "Meeting aziendale"
        ),
        array("orario" => "20:30",
              "descrizione" => "Partita"
        ),
    );
    // Ritorna
    echo json_encode($eventi);

?>