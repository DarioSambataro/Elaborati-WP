<?php

      // Connessione al database
      $conn = mysqli_connect("localhost", "root", "", "test");
      // Inizializza array di eventi
      $eventi = array();
      // Leggi eventi
      $res = mysqli_query($conn, "SELECT * FROM agenda ORDER BY orario");
      while($row = mysqli_fetch_assoc($res))
      {
            $eventi[] = $row;
      }
      // Chiudi
      mysqli_free_result($res);
      mysqli_close($conn);
      // Ritorna
      echo json_encode($eventi);

?>