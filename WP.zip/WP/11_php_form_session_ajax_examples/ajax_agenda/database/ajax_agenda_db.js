function onJSON(json)
{
    const lista = document.querySelector("ul");
    lista.innerHTML = '';
    for(evento of json)
    {
        const li = document.createElement("li")
        const orario = document.createElement("em");
        orario.textContent = evento.orario + ": ";
        const descrizione = document.createElement("span");
        descrizione.textContent = evento.descrizione + " ";
        const elimina = document.createElement("a");
        elimina.href = '#';
        elimina.dataset.id_evento = evento.orario;
        elimina.textContent = "Elimina";
        elimina.classList.add("small");
        elimina.addEventListener("click", eliminaEvento);
        li.appendChild(orario);
        li.appendChild(descrizione);
        li.appendChild(elimina);
        lista.appendChild(li);
    }
}

function eliminaEvento(event)
{
	const formData = new FormData();
	formData.append('id', event.currentTarget.dataset.id_evento);
    fetch("http://localhost/11_examples/ajax_agenda/database/ajax_agenda_db_delete.php", { method: 'POST', body: formData }).then(aggiornaEventi);
}

function responseAggiorna(response)
{
    return response.json();
}

function aggiornaEventi()
{
    // Richiedi lista eventi
    fetch("http://localhost/11_examples/ajax_agenda/database/ajax_agenda_db_get.php").then(responseAggiorna).then(onJSON);
}

function responseAggiungi(response)
{
    // Aggiorna eventi
    aggiornaEventi();
}

function aggiungiEvento(event)
{
    // Leggi form
    const form = document.querySelector("form");
    // Invia richiesta con POST
    const form_data = {method: 'post', body: new FormData(form)};
    fetch("http://localhost/11_examples/ajax_agenda/database/ajax_agenda_db_add.php", form_data).then(responseAggiungi);
    // Impedisci submit
    event.preventDefault();
}


// Carica inizialmente la lista di eventi
aggiornaEventi();
// Associa event listener al form
document.querySelector("form").addEventListener("submit", aggiungiEvento);