<?php

      // Verifica dati POST
      if(isset($_POST["orario"]) && isset($_POST["descrizione"]))
      {
            // Connessione al database
            $conn = mysqli_connect("localhost", "root", "", "test");
            // Aggiungi evento
            $orario = mysqli_real_escape_string($conn, $_POST["orario"]);
            $descrizione = mysqli_real_escape_string($conn, $_POST["descrizione"]);
            mysqli_query($conn, "INSERT INTO agenda(orario, descrizione) VALUES(\"$orario\", \"$descrizione\")");
            // Chiudi connessione
            mysqli_close($conn);
      }

?>