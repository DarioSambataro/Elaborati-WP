		
		
		
		<?php

			  // Verifica dati GET
			  if(isset($_POST["id"]))
			  {
					// Connessione al database
					$conn = mysqli_connect("localhost", "root", "", "test");
					// Elimina evento
					$id_evento = mysqli_real_escape_string($conn, $_POST["id"]);
					mysqli_query($conn, "DELETE FROM agenda WHERE orario = '".$id_evento."'");
					// Chiudi connessione
					mysqli_close($conn);
			  }

		?>
		
		
		