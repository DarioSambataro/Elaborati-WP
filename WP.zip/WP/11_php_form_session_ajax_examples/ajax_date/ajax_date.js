function onText(text)
{
    const body = document.querySelector("body");
    const p = document.createElement("p")
    p.textContent = "Data di oggi: " + text;
    body.appendChild(p);
}

function onResponse(response)
{
    return response.text();
}

// Richiedi data
fetch("http://localhost/11_examples/ajax_date/ajax_date.php").then(onResponse).then(onText);