<?php

    $x = "abcdef";

    if(strpos($x, "abc")) // ritorna 0 -> FALSE
        echo "1) 'abc' all'inizio della stringa<br>";
    
    if(strpos($x, "abc") !== FALSE)
        echo "2) 'abc' all'inizio della stringa<br>";



?>