<?php

    // I nomi delle funzioni sono case-insensitive
    echo date("d-m-Y")."<br>";
    echo DATE("d-m-Y")."<br>";
    
    // I nomi delle parole chiavi sono case-insensitive
    echo date("d-m-Y")."<br>";
    ECHO date("d-m-Y")."<br>";
    
    // I nomi delle variabili sono case-sensitive
    $var = "Ciao";
    echo $var."<br>";
    echo $VAR."<br>";

?>