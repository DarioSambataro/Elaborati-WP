<?php

$pos = strpos("Web Programming", "Programming");
echo $pos;

?>