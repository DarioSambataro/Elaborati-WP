<pre>
<?php

function f($c, $a=10, $b=20)
{
    echo $a."<br>";
    echo $b;
}

f(100, 200);

?>
</pre>