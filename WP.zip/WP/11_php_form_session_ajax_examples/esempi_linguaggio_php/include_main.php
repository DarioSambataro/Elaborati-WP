<?php

    require('include_f___.php');

    f();

?>